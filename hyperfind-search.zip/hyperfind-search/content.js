(function () {

  console.log("[VLS] Loaded");

  let currentRoot = null;
  let cachedItems = null;
  let uiVisible = true;

  let selectedIndex = -1;
  let currentMatches = [];

  // -------------------------------
  // 🔍 FUZZY MATCH
  // -------------------------------
  function fuzzyMatch(pattern, text) {
    pattern = pattern.toLowerCase();
    text = text.toLowerCase();

    let i = 0;
    for (let j = 0; j < text.length; j++) {
      if (text[j] === pattern[i]) i++;
      if (i === pattern.length) return true;
    }
    return false;
  }

  // -------------------------------
  // 👀 WATCH FOR LIST POPUP
  // -------------------------------
  function watchForList() {
    const observer = new MutationObserver(() => {
      const el = document.querySelector("krn-ui-virtual-list");

      if (el && el !== currentRoot) {
        currentRoot = el;
        console.log("[VLS] Found list");
        cachedItems = null; // reset cache on new popup
        initUI(el);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // -------------------------------
  // 🧠 SMART SCAN (EARLY STOP)
  // -------------------------------
  async function buildFullList(rootEl, statusEl) {
    const container = rootEl.querySelector(".virtual-list-container");
    if (!container) return [];

    const scrollParent = container.parentElement;
    const itemHeight = 26;
    const maxScroll = container.scrollHeight;

    const collected = new Set();

    let lastSize = 0;
    let stagnantCycles = 0;

    console.log("[VLS] Scanning...");

    for (let y = 0; y < maxScroll; y += itemHeight * 4) {
      scrollParent.scrollTop = y;

      await new Promise(r => setTimeout(r, 50));

      rootEl.querySelectorAll("li.renderer label")
        .forEach(el => collected.add(el.textContent.trim()));

      if (collected.size === lastSize) {
        stagnantCycles++;
      } else {
        stagnantCycles = 0;
        lastSize = collected.size;
      }

      if (stagnantCycles > 8) {
        console.log("[VLS] Early stop");
        break;
      }

      if (statusEl) {
        const percent = Math.min(100, Math.floor((y / maxScroll) * 100));
        statusEl.textContent = `Scanning... ${percent}% (${collected.size})`;
      }
    }

    if (statusEl) {
      statusEl.textContent = `Loaded ${collected.size} items`;
    }

    let index = 0;
    return Array.from(collected).map(label => ({
      label,
      index: index++ * itemHeight
    }));
  }

  async function getItems(rootEl, statusEl) {
    if (!cachedItems) {
      cachedItems = await buildFullList(rootEl, statusEl);
    }
    return cachedItems;
  }

  // -------------------------------
  // 🎯 SCROLL + SELECT
  // -------------------------------
  function jumpTo(rootEl, match) {
    const container = rootEl.querySelector(".virtual-list-container");
    if (!container) return;

    const scrollParent = container.parentElement;
    scrollParent.scrollTop = match.index;

    setTimeout(() => {
      rootEl.querySelectorAll("li.renderer").forEach(li => {
        const labelEl = li.querySelector("label");

        if (labelEl && labelEl.textContent.trim() === match.label) {

          document.querySelectorAll(".vls-highlighted")
            .forEach(el => el.classList.remove("vls-highlighted"));

          li.classList.add("vls-highlighted");

          labelEl.scrollIntoView({ block: "center" });
          labelEl.click();
        }
      });
    }, 150);
  }

  // -------------------------------
  // 🎨 UI
  // -------------------------------
  function initUI(rootEl) {

    if (document.getElementById("vls-container")) return;

    const container = document.createElement("div");
    container.id = "vls-container";

    container.style.cssText = `
      position:fixed;
      top:12px;
      right:12px;
      width:270px;
      background:white;
      border:1px solid #ccc;
      z-index:99999;
      box-shadow:0 4px 10px rgba(0,0,0,0.2);
      border-radius:6px;
      font-family:Segoe UI;
    `;

    container.innerHTML = `
      <div style="background:#0078d4;color:white;padding:6px;font-size:13px;">
        Smart Search
        <span id="vls-close" style="float:right;cursor:pointer;">✖</span>
      </div>

      <input id="vls-input" placeholder="Search users..."
        style="width:95%;margin:6px;padding:5px;font-size:13px;" />

      <textarea id="vls-bulk"
        placeholder="Paste names (one per line)"
        style="width:95%;margin:6px;height:60px;font-size:12px;"></textarea>

      <button id="vls-bulk-btn"
        style="margin:6px;padding:6px;width:95%;cursor:pointer;">
        Bulk Select
      </button>

      <div id="vls-results" style="max-height:200px;overflow:auto;font-size:12px;"></div>

      <div id="vls-status" style="font-size:11px;padding:4px;color:#666;"></div>
    `;

    document.body.appendChild(container);

    const input = container.querySelector("#vls-input");
    const resultsBox = container.querySelector("#vls-results");
    const status = container.querySelector("#vls-status");
    const bulkInput = container.querySelector("#vls-bulk");
    const bulkBtn = container.querySelector("#vls-bulk-btn");

    // ✅ CLOSE BUTTON
    container.querySelector("#vls-close").onclick = () => {
      container.style.display = "none";
      uiVisible = false;
    };

    // ✅ PRELOAD SCAN
    (async () => {
      await getItems(rootEl, status);
    })();

    // -------------------------------
    // 🔎 SEARCH
    // -------------------------------
    input.addEventListener("input", async () => {
      const term = input.value.trim().toLowerCase();
      const items = await getItems(rootEl, status);

      const matches = [];

      items.forEach(item => {
        if (
          item.label.toLowerCase().includes(term) ||
          fuzzyMatch(term, item.label)
        ) {
          matches.push(item);
        }
      });

      render(matches);
    });

    // -------------------------------
    // 📋 RENDER
    // -------------------------------
    function render(matches) {
      resultsBox.innerHTML = "";
      currentMatches = matches;
      selectedIndex = -1;

      matches.slice(0, 50).forEach(m => {
        const div = document.createElement("div");

        div.textContent = m.label;
        div.style.padding = "4px";
        div.style.cursor = "pointer";

        div.onclick = () => jumpTo(rootEl, m);

        resultsBox.appendChild(div);
      });
    }

    // -------------------------------
    // ⌨️ KEYBOARD NAV
    // -------------------------------
    input.addEventListener("keydown", (e) => {
      const items = resultsBox.children;

      if (!items.length) return;

      if (e.key === "ArrowDown") {
        selectedIndex = (selectedIndex + 1) % items.length;
        update(items);
        e.preventDefault();
      }

      if (e.key === "ArrowUp") {
        selectedIndex = (selectedIndex - 1 + items.length) % items.length;
        update(items);
        e.preventDefault();
      }

      if (e.key === "Enter" && selectedIndex >= 0) {
        jumpTo(rootEl, currentMatches[selectedIndex]);
      }
    });

    function update(items) {
      Array.from(items).forEach(el => el.style.background = "");

      if (selectedIndex >= 0) {
        items[selectedIndex].style.background = "#e5f1fb";
        items[selectedIndex].scrollIntoView({ block: "nearest" });
      }
    }

    // -------------------------------
    // 🔥 BULK SELECT
    // -------------------------------
    bulkBtn.onclick = async () => {
      const raw = bulkInput.value.trim();
      if (!raw) return;

      const targets = raw
        .split("\n")
        .map(s => s.trim().toLowerCase())
        .filter(Boolean);

      const items = await getItems(rootEl, status);

      status.textContent = "Running bulk select...";

      let count = 0;
      let missed = [];

      for (const term of targets) {

        let match =
          items.find(i => i.label.toLowerCase() === term) ||
          items.find(i => i.label.toLowerCase().includes(term)) ||
          items.find(i => fuzzyMatch(term, i.label));

        if (match) {
          count++;
          jumpTo(rootEl, match);
          await new Promise(r => setTimeout(r, 250));
        } else {
          missed.push(term);
        }
      }

      status.textContent = `Selected ${count}/${targets.length} | Missed: ${missed.length}`;
      console.log("[VLS] Missed:", missed);
    };

    // -------------------------------
    // 🔘 TOGGLE SUPPORT
    // -------------------------------
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.action === "toggle-ui") {
        container.style.display = uiVisible ? "none" : "block";
        uiVisible = !uiVisible;
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "f") {
        container.style.display = uiVisible ? "none" : "block";
        uiVisible = !uiVisible;
      }
    });
  }

  // 🚀 START
  watchForList();

})();
