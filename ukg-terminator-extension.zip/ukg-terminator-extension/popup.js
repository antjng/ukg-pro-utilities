
document.getElementById('startBtn').addEventListener('click', async () => {
  const ticket = document.getElementById('ticket').value.trim();
  const termDate = document.getElementById('termDate').value.trim();
  const empIdsRaw = document.getElementById('empIds').value.trim();

  if (!ticket || !termDate || !empIdsRaw) {
    alert('Please fill in all fields.');
    return;
  }

  const empIds = empIdsRaw.split('\n').map(s => s.trim()).filter(Boolean);
  if (empIds.length === 0) {
    alert('No employee IDs provided.');
    return;
  }

  const statusDiv = document.getElementById('status');
  statusDiv.classList.add('visible');
  statusDiv.textContent = '';

  const btn = document.getElementById('startBtn');
  btn.disabled = true;
  btn.textContent = 'Running...';

  function log(msg) {
    statusDiv.textContent += msg + '\n';
    statusDiv.scrollTop = statusDiv.scrollHeight;
  }

  // Get the active tab (should be UKG Pro)
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab.url.includes('abbinc-sso.prd.mykronos.com')) {
    log('[ERROR] Active tab is not UKG Pro!');
    log('Navigate to People Information first.');
    btn.disabled = false;
    btn.textContent = '\u{1F680} Start Terminations';
    return;
  }

  log(`Ticket: ${ticket}`);
  log(`Date: ${termDate}`);
  log(`Employees: ${empIds.length}`);
  log('\u2500'.repeat(40));

  for (let i = 0; i < empIds.length; i++) {
    const empId = empIds[i];
    log(`\n[${i + 1}/${empIds.length}] Processing ${empId}...`);

    try {
      // Take BEFORE screenshot
      log('  \u{1F4F8} Before screenshot...');
      const beforeImg = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      await downloadDataUrl(beforeImg, `UKG Evidence/${ticket} ${empId} - before.png`);

      // Inject and run the automation
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: terminateEmployee,
        args: [empId, termDate]
      });

      const result = results[0].result;

      if (result.error) {
        log(`  \u274C ERROR: ${result.error}`);
        continue;
      }

      log(`  ${result.message}`);

      // Wait for save to complete
      await sleep(3000);

      // Take AFTER screenshot
      log('  \u{1F4F8} After screenshot...');
      const afterImg = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      await downloadDataUrl(afterImg, `UKG Evidence/${ticket} ${empId} - after.png`);

      log('  \u2705 Done!');

    } catch (e) {
      log(`  \u274C FAILED: ${e.message}`);
    }

    // Brief pause between employees
    if (i < empIds.length - 1) {
      log('  \u23F3 Waiting before next...');
      await sleep(2000);
    }
  }

  log('\n' + '\u2550'.repeat(40));
  log('\u{1F389} ALL DONE!');
  btn.disabled = false;
  btn.textContent = '\u{1F680} Start Terminations';
});

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function downloadDataUrl(dataUrl, filename) {
  await chrome.downloads.download({
    url: dataUrl,
    filename: filename,
    saveAs: false
  });
}

// ============================================================
// This function is injected into the UKG Pro page
// ============================================================
function terminateEmployee(empId, termDate) {
  return new Promise((resolve) => {
    const delay = (ms) => new Promise(r => setTimeout(r, ms));

    (async () => {
      try {
        // --- Step 1: Search for employee ---
        const searchInput = document.querySelector('#peEmpList input.pe-search-box');
        if (!searchInput) {
          resolve({ error: 'Could not find employee search box. Are you on People Information page?' });
          return;
        }

        // Clear and type employee ID using native input setter to trigger Angular/React bindings
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
          window.HTMLInputElement.prototype, 'value'
        ).set;

        nativeInputValueSetter.call(searchInput, '');
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        await delay(300);

        nativeInputValueSetter.call(searchInput, empId);
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        searchInput.dispatchEvent(new Event('keyup', { bubbles: true }));

        await delay(2500);

        // Click the matching employee in the dropdown
        const listItems = document.querySelectorAll('#peEmpListDropDown li');
        let found = false;
        for (const li of listItems) {
          if (li.textContent.includes(empId)) {
            li.click();
            found = true;
            break;
          }
        }
        if (!found) {
          resolve({ error: `Employee ${empId} not found in search results` });
          return;
        }

        await delay(3000);

        // Wait for loader to disappear
        for (let i = 0; i < 20; i++) {
          const loader = document.querySelector('.pe-loader');
          if (!loader || loader.style.display === 'none' || !loader.offsetParent) break;
          await delay(500);
        }

        // --- Step 2: Find Employment Status grids ---
        const statusGrids = document.querySelectorAll('krn-pe-status-grid');
        if (statusGrids.length < 2) {
          resolve({ error: `Expected 2 status grids, found ${statusGrids.length}` });
          return;
        }

        // Process both grids (Employment Status + User Account Status)
        const gridNames = ['Employment Status', 'User Account Status'];
        for (let g = 0; g < 2; g++) {
          const grid = statusGrids[g];
          const jqxGrid = grid.querySelector('.jqx-grid');
          if (!jqxGrid) {
            resolve({ error: `Could not find jqx-grid in ${gridNames[g]}` });
            return;
          }
          const gridId = jqxGrid.id;

          // Find row1 (the empty/new row)
          const row1 = document.querySelector(`#row1${gridId}`);
          if (!row1) {
            resolve({ error: `Could not find row1 for ${gridNames[g]} (grid: ${gridId})` });
            return;
          }

          // Click the + (Add Row) button
          const addBtn = row1.querySelector('[title="Add Row"], .icon-k-plus');
          if (addBtn) {
            addBtn.click();
            await delay(1200);
          }

          // Click the status cell (3rd cell) in row1
          const cells = row1.querySelectorAll('div[role="gridcell"]');
          if (cells.length >= 3) {
            cells[2].click();
            await delay(800);

            // Try to find the input/combo that appeared and type "Terminated"
            const activeEl = document.activeElement;
            if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
              nativeInputValueSetter.call(activeEl, 'Terminated');
              activeEl.dispatchEvent(new Event('input', { bubbles: true }));
              await delay(600);
            }

            // Find and click "Terminated" in the dropdown
            await delay(400);
            const allOptions = document.querySelectorAll(
              '.jqx-listbox-container .jqx-listitem-element, ' +
              '.jqx-popup li, [role="option"], .jqx-fill-state-normal'
            );
            for (const opt of allOptions) {
              if (opt.textContent.trim() === 'Terminated' && opt.offsetParent !== null) {
                opt.click();
                break;
              }
            }
            await delay(800);
          }

          // Click the date cell (4th cell)
          if (cells.length >= 4) {
            cells[3].click();
            await delay(800);

            // Find the jqxDateTimeInput
            const dateInput = document.querySelector('input[id^="inputdatetimeeditor"]') ||
                              row1.querySelector('input[type="text"]');
            if (dateInput) {
              dateInput.focus();
              dateInput.select();
              document.execCommand('selectAll');
              document.execCommand('insertText', false, termDate);
              dateInput.dispatchEvent(new Event('change', { bubbles: true }));
              dateInput.dispatchEvent(new Event('blur', { bubbles: true }));
              await delay(500);
            }
          }

          await delay(500);
        }

        // --- Step 3: Click Save ---
        const saveBtn = document.querySelector(
          '#com\\.kronos\\.wfc\\.ngui\\.peopleeditor\\.save button, ' +
          'button[aria-label="Save"], ' +
          'button.pe-save-btn, ' +
          'button[title="Save"]'
        );
        if (saveBtn) {
          saveBtn.click();
          await delay(2000);
        } else {
          resolve({ error: 'Could not find Save button' });
          return;
        }

        // Wait for save to complete
        for (let i = 0; i < 20; i++) {
          const loader = document.querySelector('.pe-loader');
          if (!loader || loader.style.display === 'none' || !loader.offsetParent) break;
          await delay(500);
        }

        resolve({ message: 'Termination applied and saved.' });

      } catch (e) {
        resolve({ error: e.message });
      }
    })();
  });
}
